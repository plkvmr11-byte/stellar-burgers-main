import { OrderStatus } from '@components';
import {
  CurrencyIcon,
  FormattedDate,
} from '@krgaa/react-developer-burger-ui-components';
import { memo } from 'react';

import type { OrderInfoUIProps } from './type';

import styles from './order-info.module.css';

export const OrderInfoUI = memo(function OrderInfoUI({
  orderInfo,
}: OrderInfoUIProps): React.JSX.Element {
  return (
    <div className={styles.wrap}>
      <h3 className={`text text_type_main-medium  pb-3 pt-10 ${styles.header}`}>
        {orderInfo.name}
      </h3>
      <OrderStatus status={orderInfo.status} />
      <p className={`text text_type_main-medium pt-15 pb=6`}>Состав:</p>
      <ul className={`${styles.list} mb-8`}>
        {Object.values(orderInfo.ingredientsInfo).map((item, index) => (
          <li className={`pb-4 pr-6 ${styles.item}`} key={index}>
            <div className={styles.img_wrap}>
              <div className={styles.border}>
                <img className={styles.img} src={item.image_mobile} alt={item.name} />
              </div>
            </div>
            <span className="text text_type_main-default pl-4">{item.name}</span>
            <span
              className={`text text_type_digits-default pl-4 pr-4 ${styles.quantity}`}
            >
              {item.count} x {item.price}
            </span>
            <CurrencyIcon type={'primary'} />
          </li>
        ))}
      </ul>
      <div className={styles.bottom}>
        <p className="text text_type_main-default text_color_inactive">
          <FormattedDate date={orderInfo.date} />
        </p>
        <span className={`text text_type_digits-default pr-4 ${styles.total}`}>
          {orderInfo.total}
        </span>
        <CurrencyIcon type={'primary'} />
      </div>
    </div>
  );
});
